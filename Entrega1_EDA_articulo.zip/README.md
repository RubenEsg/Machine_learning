# Artículo — Entrega 1: Análisis Exploratorio de Datos

Universidad del Norte · Machine Learning
Martínez Pulido, Valerie · Basto Martínez, Abrahan · Esguerra Fernández, Rubén

## Contenido

| Archivo | Para qué sirve |
|---|---|
| `main.tex` | Versión con la **plantilla Springer Nature** (la del ejemplo del curso). Úsala en Overleaf. |
| `main_autocontenido.tex` | **Mismo contenido**, con la clase `article`. Compila en cualquier parte sin plantilla. |
| `main_autocontenido.pdf` | PDF ya compilado (22 páginas) para revisar de inmediato. |
| `sn-bibliography.bib` | Referencias en BibTeX. |
| `figuras/` | Las 18 figuras del EDA (PNG, paleta azul). |

## Opción A — Overleaf con la plantilla Springer Nature (recomendada)

1. Entra a Overleaf → **New Project** → **Templates** → busca *Springer Nature LaTeX Template* → **Open as Template**.
2. En el panel de archivos, **sube** `main.tex` (reemplazando el que trae la plantilla), la carpeta `figuras/`
   y `sn-bibliography.bib` (la plantilla ya trae un archivo con ese nombre: reemplázalo o pega dentro las entradas).
3. Compila con **pdfLaTeX**. Si el menú de compilador está en otro motor, cámbialo en *Menu → Compiler → pdfLaTeX*.

> Nota: la clase `sn-jnl` solo existe dentro de esa plantilla; por eso `main.tex` no compila fuera de Overleaf.

## Opción B — Compilar sin plantilla (cualquier instalación de LaTeX)

```bash
pdflatex main_autocontenido.tex
bibtex   main_autocontenido
pdflatex main_autocontenido.tex
pdflatex main_autocontenido.tex
```

O en Overleaf: crea un proyecto en blanco y sube `main_autocontenido.tex`, `sn-bibliography.bib` y `figuras/`.

## Fuente de los datos

COFINFAD: Colombian Fintech Financial Analytics Dataset (Muñoz Guerrero, Ceballos y Trejos Rojas),
Mendeley Data, 2025. DOI 10.17632/mhb4zn3258.1 — licencia CC BY 4.0.
https://data.mendeley.com/datasets/mhb4zn3258/1

## Nota

- Las secciones de modelado (baselines, modelo propuesto, configuración experimental y resultados)
  corresponden a la **Entrega 2** y por eso no se incluyen en este documento.
